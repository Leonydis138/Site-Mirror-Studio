import { type ReactNode } from 'react';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { ErrorBoundary } from '@/components/error-boundary';
import { Toaster } from '@/components/ui/toaster';
import { TooltipProvider } from '@/components/ui/tooltip';
import MirrorHome from '@/pages/mirror-home';
import MirrorHistory from '@/pages/mirror-history';
import MirrorJobPage from '@/pages/mirror-job';
import MirrorPreviewPage from '@/pages/mirror-preview';
import MirrorArchivePage from '@/pages/mirror-archive';
import NotFound from '@/pages/not-found';
import {
  Route,
  Switch,
  useLocation,
  Router as WouterRouter,
} from 'wouter';

const queryClient = new QueryClient();

function Router() {
  return (
    // Keep a shared shell (sidebar, navbar) outside the boundary so it
    // survives a page crash.
    <RoutedErrorBoundary>
      <Switch>
        <Route path="/" component={MirrorHome} />
        <Route path="/history" component={MirrorHistory} />
        <Route path="/jobs/:id/preview" component={MirrorPreviewPage} />
        <Route path="/jobs/:id/archive" component={MirrorArchivePage} />
        <Route path="/jobs/:id" component={MirrorJobPage} />
        <Route component={NotFound} />
      </Switch>
    </RoutedErrorBoundary>
  );
}

function RoutedErrorBoundary({ children }: { children: ReactNode }) {
  const [location] = useLocation();
  return <ErrorBoundary resetKey={location}>{children}</ErrorBoundary>;
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <WouterRouter base={import.meta.env.BASE_URL.replace(/\/$/, '')}>
          <Router />
        </WouterRouter>
        <Toaster />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
