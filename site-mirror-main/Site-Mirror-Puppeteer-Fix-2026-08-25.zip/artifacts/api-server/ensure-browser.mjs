import { access, mkdir } from 'node:fs/promises';
import { execFileSync } from 'node:child_process';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const here = path.dirname(fileURLToPath(import.meta.url));
const cacheDir = path.join(here, '.cache', 'puppeteer');
process.env.PUPPETEER_CACHE_DIR = cacheDir;
await mkdir(cacheDir, { recursive: true });

const { default: puppeteer } = await import('puppeteer');
const executablePath = puppeteer.executablePath();

console.log(`[puppeteer] Expected Chrome: ${executablePath}`);

async function exists(file) {
  try {
    await access(file);
    return true;
  } catch {
    return false;
  }
}

if (await exists(executablePath)) {
  console.log('[puppeteer] Required Chrome is already installed.');
  process.exit(0);
}

console.log('[puppeteer] Required Chrome is missing; installing the browser revision required by this Puppeteer package...');

try {
  execFileSync('pnpm', ['exec', 'puppeteer', 'browsers', 'install', 'chrome'], {
    cwd: here,
    env: { ...process.env, PUPPETEER_CACHE_DIR: cacheDir },
    stdio: 'inherit',
  });
} catch (error) {
  console.error('[puppeteer] Chrome installation failed.', error);
  process.exit(1);
}

if (!(await exists(puppeteer.executablePath()))) {
  console.error(`[puppeteer] Installation completed, but Chrome was not found at: ${puppeteer.executablePath()}`);
  process.exit(1);
}

console.log(`[puppeteer] Chrome is ready: ${puppeteer.executablePath()}`);
